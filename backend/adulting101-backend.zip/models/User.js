const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true },
    password: { type: String, required: true }, // Muista kryptata tämä myöhemmin!
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('users', userSchema);
